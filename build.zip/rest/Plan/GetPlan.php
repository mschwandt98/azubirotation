<?php
use Core\Helper\DataHelper;
use Core\Helper\DateHelper;
use Models\Plan;

session_start();
include_once(dirname(dirname(__DIR__)) . "/config.php");

if (is_logged_in() && is_token_valid()) {

    if (array_key_exists("showError", $_POST)) {


    }

    http_response_code(400);
    exit;
}

http_response_code(401);
