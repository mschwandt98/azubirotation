<div class="settings-box">
    <label>
        Termin eintragen <input id="SetMark" type="checkbox" />
    </label>
</div>
