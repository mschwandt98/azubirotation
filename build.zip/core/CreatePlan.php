<?php
/**
 * CreatePlan.php
 *
 * Erstellt eine Planung für einen Azubi.
 *
 * Für das Skript muss die Variable $azubi_id gesetzt sein.
 */

use Core\Helper\DataHelper;
use Core\Helper\DateHelper;

if (empty($azubi_id)) return;
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

include_once(dirname(__DIR__) . "/config.php");

if (!is_logged_in()) return;

include_once(HELPER . "/DataHelper.php");
include_once(HELPER . "/DateHelper.php");

$helper = new DataHelper();

$azubi = $helper->GetAzubis($azubi_id);
$ausbildungsberuf = $helper->GetAusbildungsberufe($Azubi->ID_Ausbildungsberuf);
$standardplan = array_shift($helper->GetStandardPlaene($azubi->ID_Ausbildungsberuf));

if (empty($standardplan)) return;

// Plaene und Abteilungen werden als globals in dieser Datei genutzt
$Plaene = $helper->GetPlaene();
$Abteilungen = [];
foreach ($helper->GetAbteilungen() as $abteilung) {
    $Abteilungen[$abteilung->ID] = $abteilung;
}

$praeferierteAbteilungen    = [];
$normaleAbteilungen         = [];
$optionaleAbteilungen       = [];
foreach ($standardplan->Phasen as $phase) {

    if ($phase->Praeferieren && !$phase->Optional) {
        $praeferierteAbteilungen[] = $phase;
    } elseif ($phase->Praeferieren && $phase->Optional) {
        $praeferierteOptionaleAbteilungen[] = $phase;
    } elseif (!$phase->Praeferieren && !$phase->Optional) {
        $normaleAbteilungen[] = $phase;
    } elseif (!$phase->Praeferieren && $phase->Optional) {
        $optionaleAbteilungen[] = $phase;
    }
}

$abteilungen = [
    "Praeferierte"          => $praeferierteAbteilungen,
    "PraeferierteOptionale" => $praeferierteAbteilungen,
    "Normale"               => $normaleAbteilungen,
    "Optionale"             => $optionaleAbteilungen
];

$phasen = [];
$startDate = $azubi->Ausbildungsstart;

if (!empty($abteilungen["Praeferierte"])) {

    foreach ($abteilungen["Praeferierte"] as $abteilung) {

        // $abteilung =
    }
}

GetBelegteZeitraeumeInAbteilungen();

/**
 *
 */
function GetBelegteZeitraeumeInAbteilungen() {

    global $Abteilungen;
    global $Plaene;

    $abteilungsPlaene = [];
    $belegteZeitraeume = []; // ... in Abteilungen
    foreach ($Abteilungen as $abteilung) {
        $abteilungsPlaene[$abteilung->ID] = [];
        $belegteZeitraeume = [$abteilung->ID] = [];
    }

    foreach ($Plaene as $plan) {
        $abteilungsPlaene[$plan->ID_Abteilung][] = $plan;
    }

    foreach ($abteilungsPlaene as $id_abteilung => $plaene) {

        if (empty($plaene)) continue;

        foreach ($plaene as $plan) {

            $startDate = $plan->Startdatum;
            $endDate = $plan->Enddatum;
            $timePeriodString = DateHelper::BuildTimePeriodString($startDate, $endDate);

            if (empty($belegteZeitraeume[$id_abteilung])) {
                $belegteZeitraeume[$id_abteilung][$timePeriodString] = 1;
                continue;
            }

            foreach ($belegteZeitraeume[$id_abteilung] as $zeitraum => $anzahlAzubis) {

                $tempBelegteAbteilungen = [];
                $dates                  = DateHelper::GetDatesFromString($zeitraum);
                $belegtStartdatum       = DateHelper::FormatDate($dates["StartDatum"], "Y-m-d");
                $belegtEnddatum         = DateHelper::FormatDate($dates["EndDatum"], "Y-m-d");

                if ($timePeriodString === $zeitraum) { // Zeitspannen übereinstimmend
                    $belegteZeitraeume[$id_abteilung][$zeitraum]++;
                } elseif ($startDate === $belegtStartdatum && $endDate < $belegtEnddatum) { // Anfang gleich und Ende kleiner

                    $tempBelegteAbteilungen[DateHelper::BuildTimePeriodString($startDate, $endDate)] = $anzahlAzubis + 1;
                    $tempBelegteAbteilungen[DateHelper::BuildTimePeriodString(
                        DateHelper::DayAfter($endDate), $belegtEnddatum
                    )] = $anzahlAzubis;

                } elseif ($startDate > $belegtStartdatum && $endDate < $belegtEnddatum) { // Anfang und Ende in Zeitspanne

                    $tempBelegteAbteilungen[DateHelper::BuildTimePeriodString(
                        $belegtStartdatum, DateHelper::DayBefore($startDate)
                    )] = $anzahlAzubis;
                    $tempBelegteAbteilungen[DateHelper::BuildTimePeriodString($startDate, $endDate)] = $anzahlAzubis + 1;
                    $tempBelegteAbteilungen[DateHelper::BuildTimePeriodString(
                        DateHelper::DayAfter($endDate), $belegtEnddatum
                    )] = $anzahlAzubis;

                } elseif ($startDate > $belegtStartdatum && $endDate === $belegtEnddatum) { // Anfang größer und Ende gleich

                    $tempBelegteAbteilungen[DateHelper::BuildTimePeriodString(
                        $belegtStartdatum, DateHelper::DayBefore($startDate)
                    )] = $anzahlAzubis;
                    $tempBelegteAbteilungen[DateHelper::BuildTimePeriodString($startDate, $endDate)] = $anzahlAzubis + 1;

                }/* elseif ($startDate < $belegtStartdatum && $endDate < $belegtEnddatum) { //

                    $tempBelegteAbteilungen[DateHelper::BuildTimePeriodString(

                    )] = ;

                } elseif ($startDate < $belegtStartdatum && $endDate === $belegtEnddatum) { //

                } elseif ($startDate > $belegtStartdatum && $endDate > $belegtEnddatum) { //

                } elseif ($startDate === $belegtStartdatum && $endDate > $belegtEnddatum) { //

                }*/

                if (!empty($tempBelegteAbteilungen)) {

                    unset($belegteZeitraeume[$id_abteilung][$zeitraum]);

                    foreach ($tempBelegteAbteilungen as $zeitraum => $azubis) {
                        $belegteZeitraeume[$id_abteilung][$zeitraum] = $azubis;
                    }
                }
            }
        }
    }

    $test = 0;
    $belegteZeitraeume = $belegteZeitraeume;
}

/**
 * Untersucht, ob für den gegebenen Zeitraum die Abteilung bereits verplant ist.
 */
function IsZeitraumInAbteilungFrei($timePeriod, $id_abteilung) {

    global $Abteilungen;
    global $Plaene;

    $abteilung = $Abteilungen[$id_abteilung];



    return true;
}
